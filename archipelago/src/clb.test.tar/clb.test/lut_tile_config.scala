package fpga_components
{

import Chisel._
import scala.math._

object LutConstants { 
    // LUT CONFIG
    var VAR_NUM_INPUTS_PER_LUT = 6
    var VAR_NUM_OUTPUTS_PER_LUT = 1
    var VAR_NUM_CONFIGS_PER_LUT = 64
    var VAR_NUM_MUXES_PER_LUT = 1 
    // CLB CONFIG
    var VAR_NUM_CLB_IN = 60
    var VAR_NUM_CLB_OUT = 10
    var VAR_NUM_LUTS_PER_CLB = 10
    var VAR_NUM_CLB_LUT_CONFIGS = 640
    var VAR_NUM_CLB_MUX_CONFIGS = 10
    var VAR_TOTAL_MUX_CONFIGS = 10
}

}
